ATK or DEF — Windows x64
Run ATKorDEF.exe. Keep the executable, Data, runtime DLLs and subfolders together.
Exclude any BackUpThisFolder_ButDontShipItWithYourGame folder when sharing.
AI mode is available offline. Internet rooms require the configured Unity Cloud services.
This build's Internet acceptance is pending: the current cloud service returned HTTP 451 during verification.
Font license: ThirdPartyNotices/SourceHanSans-OFL.txt
